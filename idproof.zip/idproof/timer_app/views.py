# timer_app/views.py

from django.shortcuts import render, redirect
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.contrib import messages
from .forms import RegistrationForm
from .models import User

from django.shortcuts import render

def policy(request):
    return render(request, 'timer_app/policy.html')

def home(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']

            # Проверяем, существует ли уже пользователь с таким email или username
            if User.objects.filter(email=email).exists():
                form.add_error('email', 'Пользователь с этим email уже зарегистрирован.')
            elif User.objects.filter(username=username).exists():
                form.add_error('username', 'Пользователь с этим именем уже зарегистрирован.')
            else:
                # Создаем нового пользователя
                user = User.objects.create(username=username, email=email)

                # Отправляем письмо с кодом
                try:
                    send_code_to_email(email, user.user_code)
                    messages.success(request, 'Регистрация прошла успешно! Код отправлен на вашу почту.')
                except Exception as e:
                    messages.error(request, 'Не удалось отправить письмо. Попробуйте позже.')

                # Перенаправляем на страницу успешной регистрации
                return redirect('success', user_code=user.user_code)
    else:
        form = RegistrationForm()

    return render(request, 'timer_app/home.html', {'form': form})


def success(request, user_code):
    try:
        user = User.objects.get(user_code=user_code)
        return render(request, 'timer_app/success.html', {'code': user.user_code})
    except User.DoesNotExist:
        return render(request, 'timer_app/error.html', {'message': 'Пользователь не найден'})


def send_code_to_email(user_email, user_code):
    subject = 'Ваш уникальный код IDPROOF'
    html_message = render_to_string('timer_app/email_template.html', {'code': user_code})
    plain_message = strip_tags(html_message)  # Текстовая версия письма
    from_email = 'ваш_email@gmail.com'  # Укажите ваш email
    recipient_list = [user_email]

    send_mail(
        subject,
        plain_message,
        from_email,
        recipient_list,
        html_message=html_message,
    )