# timer_app/forms.py

from django import forms
from captcha.fields import CaptchaField  # Импортируем CaptchaField

class RegistrationForm(forms.Form):
    username = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={'class': 'form-input'}),
        label="Имя пользователя"
    )
    email = forms.EmailField(
        widget=forms.EmailInput(attrs={'class': 'form-input'}),
        label="Email"
    )
    privacy_policy = forms.BooleanField(
        required=True,
        label="Я согласен с политикой конфиденциальности"
    )
    captcha = CaptchaField(  # Добавляем поле капчи
        label="Введите текст с картинки",
        error_messages={
            'invalid': 'Попробуйте еще раз',  # Настройка сообщения об ошибке
        }
    )