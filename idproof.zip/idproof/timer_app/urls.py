# timer_app/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('success/<str:user_code>/', views.success, name='success'),
    path('policy/', views.policy, name='policy'),  # Добавьте маршрут для политики
]